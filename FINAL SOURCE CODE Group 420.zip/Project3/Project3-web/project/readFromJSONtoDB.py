#import requests
from flask import Flask
import json
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import desc, DECIMAL
from sqlalchemy import create_engine
from sqlalchemy import Column
from sqlalchemy import Integer
from sqlalchemy import String
from sqlalchemy.ext.declarative import declarative_base 
from sqlalchemy.orm import sessionmaker
import sqlite3 as lite
import psycopg2



#CONVERTING JSON TO VARIABLE
#jsondata = '{"gtw_id":"eui-b827ebfffea4e3a0","timestamp":131745915,"time":"2019-12-09T07:28:27.973126Z","channel":0,"rssi":-83,"snr":10,"rf_chain":1,"latitude":96.04213,"longitude":90.19462}'
# read file
with open('output.json', 'r') as myfile:
    data=myfile.read()
# parse file
obj = json.loads(data)
# show values
print("latitude: " + str(obj['payload_fields']['gps_1']['latitude']))
print("longitude: " + str(obj['payload_fields']['gps_1']['longitude']))
print("time: " + str(obj['metadata']['time']))
#variable used to store into database
longitudeData = obj['payload_fields']['gps_1']['longitude']
latitudeData = obj['payload_fields']['gps_1']['latitude']


#DATABASE
engine = create_engine('sqlite:///project/site.db', echo=True)
Session = sessionmaker(bind=engine)
session = Session()
Base = declarative_base()

class Location(Base):
    __tablename__ = 'location'
    id = Column(Integer, primary_key=True)
    longitude = Column(DECIMAL(9,6), unique=False)
    latitude = Column(DECIMAL(9,6), unique=False)

    def __repr__(self):
        return f'location{self.longitude, self.latitude}'

Base.metadata.create_all(engine)
recording = Location(longitude=longitudeData, latitude=latitudeData)
#recording = Location(longitude =99.99999, latitude= 99.99999)
print(recording)
session.add(recording)
session.commit()

#testing if stored succesfully 
conn = lite.connect('project/site.db')
cur = conn.cursor()
def get_location():
    with conn:
        cur.execute("SELECT * FROM location")
        print(cur.fetchall())
get_location()

