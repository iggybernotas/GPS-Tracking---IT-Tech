#!/usr/bin/python3

#-----------------------------------------------------------
# Script for loading mqtt messages from the things network

# ----------------------------------------------------------

import paho.mqtt.client as mqtt
import json

APPID = "whatever123"
PSW = "ttn-account-v2.AkMvm21p8dJUxIs2ZgLJzQVukViyAR7KlzK2v0jjyz8"

# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe('+/devices/+/up')

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    data = str(msg.payload)
    new_data = data.split("b'")
    newer_data = new_data[1]
    newest_data = newer_data[:-1]
    print("Data collected: "+ str(newest_data))
    print(newest_data, file=open("output.json", "w"))
    print("success")

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.username_pw_set(APPID, password=PSW)
client.connect("eu.thethings.network", 1883, 60)

client.loop_forever()

