import machine
import math
import network
import os
import time
import utime
import gc
from machine import RTC
from machine import SD
from L76GNSS import L76GNSS
from pytrack import Pytrack
from CayenneLPP import CayenneLPP
import pycom
#LoRa
from network import LoRa
import socket
import ubinascii
import struct
# #LORA ABP SETUP
lora = LoRa(mode=LoRa.LORAWAN, region =LoRa.EU868)
dev_addr = struct.unpack(">l", ubinascii.unhexlify('260114B3'))[0]
nwk_swkey = ubinascii.unhexlify('F6D5D7AD460C8C35D482CAF00DD49525')
app_swkey = ubinascii.unhexlify('285BAF860340B51D26C8E53341B4CEA2')
lora.join(activation=LoRa.ABP, auth=(dev_addr, nwk_swkey, app_swkey))
while not lora.has_joined():
    time.sleep(2.5)
    print('Not yet joined...')
print('Joined LoRA')
# DO NOT TOUCH THIS SHIT
time.sleep(2)
gc.enable()
# setup rtc
rtc = machine.RTC()
rtc.ntp_sync("pool.ntp.org")
utime.sleep_ms(750)
print('\nRTC Set from NTP to UTC:', rtc.now())
utime.timezone(7200)
print('Adjusted from UTC to EST timezone', utime.localtime(), '\n')
py = Pytrack()
l76 = L76GNSS(py, timeout=30)
#DO NOT TOUCH THIS SHIT
# sd = SD()
# os.mount(sd, '/sd')
# f = open('/sd/gps-record.txt', 'w')

# create a LoRa socket
s = socket.socket(socket.AF_LORA, socket.SOCK_RAW)
# set the LoRaWAN data rate
s.setsockopt(socket.SOL_LORA, socket.SO_DR, 5)
while (True):
    coord = l76.coordinates()
    #f.write("{} - {}\n".format(coord, rtc.now()))
    print("{} - {} - {}".format(coord, rtc.now(), gc.mem_free()))
    #SENDING TO LORA
    s.setblocking(True)
    #pycom.rgbled(0x000014)
    lpp = CayenneLPP()
    if coord[0] == None or coord[1] == None:
        print('No GPS')
        #s.send(bytes([0x01, 0x02, 0x03])) #REOMOVE THIS WHEN LORA IS WORKING
        time.sleep(2)
        l76 = L76GNSS(py, timeout=30)
    else:
        print('Latitude', coord[0])
        print('Longitude', coord[1])
        lpp.add_gps(1, coord[0], coord[1], 0)
    print('Sending data (uplink)...')
    s.send(bytes(lpp.get_buffer()))
    s.setblocking(False)
    time.sleep(10)
